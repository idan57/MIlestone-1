//
// Created by idan on 15/12/2019.
//

#ifndef MILESTONE_1_EXTRA_H
#define MILESTONE_1_EXTRA_H

#include <iostream>
#include <map>
using namespace std;
class Extra {
public:
    static map<string,int>* initializeDirectories();
};


#endif //MILESTONE_1_EXTRA_H
