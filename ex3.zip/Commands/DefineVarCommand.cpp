//
// Created by liad on 16/12/2019.
//

#include "DefineVarCommand.h"
#include "../Expressions/ex1.h"
#include <thread>
#include <string>


int DefineVarCommand::execute() {


    double num = 0;
    int flag = 0;
    vector<string> *parsed = new vector<string>;
    parsed = this->parse(0);
    // check if this is new variable
    if (parsed->at(0) == "var") {

        parsed = this->parse(2);
        // check if local variable or variable that belongs to the simulator
        if (parsed->at(1) == "=") {
            string var = parsed->at(0);
            string val = parsed->at(2);
            num = this->setVar(val)->calculate();
            string str = string(var);
            Var *v = new Var(var,num);
            symbolTable->variables->insert({str,v});
        } else {

            vector<string> *sim = this->parse(0);
            Var *v = new Var(parsed->at(0), 0);
            string path = string((sim->at(0)));
            path.erase(
                    remove( path.begin(), path.end(), '\"' ),
                    path.end()
            );

            // update the maps according to directions
            symbolTable->variables->insert({path, v});
            if (parsed->at(1) == "->") {
                symbolTable->ClientUpdate->insert({symbolTable->clientVar, path});
                symbolTable->clientVar++;
            } else {
                symbolTable->ServerUpdate->insert({symbolTable->serverVar, path});
                symbolTable->serverVar++;
            }
        }

    } else {

        string nameOfVar = parsed->at(0);
        parsed = this->parse(1);
        string val = parsed->at(1);

        // evaluate and set value to exist variable
        auto it = symbolTable->variables->begin();
        while (it != symbolTable->variables->end()) {
            if ((it->second->GetPath()) == nameOfVar) {
                Expression* value = this->setVar(val);
                double d = value->calculate();
                it->second->SetValue(d);
                break;
            }
            it++;
        }
    }
}
