//
// Created by liad on 16/12/2019.
//

#include "PrintCommand.h"

int PrintCommand::execute() {

    vector<string>* parsed = this->parse(1);
    /*
    parsed->at(1).erase(
            remove( parsed->at(1).begin(), parsed->at(1).end(), '\"' ),
            parsed->at(1).end()
    );*/


/*
    int flag = 0;
    for (int i = 0; i < parsed->at(1).size(); i++) {
        if(parsed->at(1)[i] == '"') {
            flag = 1;
            break;
        }
    }
    if (flag == 1) {
        cout << parsed->at(1) << "\n";
    }
    else {
        double d = this->setVar(parsed->at(1))->calculate();
        printf("%lf\n",d);
    }*/



    for (auto it = this->symbolTable->variables->begin(); it != this->symbolTable->variables->end(); it++) {
        if (it->second->GetPath() == parsed->at(1)) {
            cout << it->second->GetValue() << endl;
            return 1;
        }

    }
    cout << parsed->at(1) << "\n";

}