//
// Created by liad on 16/12/2019.
//

#include "PrintCommand.h"

int PrintCommand::execute() {

    vector<string>* parsed = this->parse(1);
    int flag = 0;
    for (int i = 0; i < parsed->at(1).size(); i++) {
        if(parsed->at(1)[i] == '"') {
            flag = 1;
            break;
        }
    }
    if (flag == 1) {
        cout << parsed->at(1) << "\n";
    }
    else {
        double d = this->setVar(parsed->at(1))->calculate();
        printf("%lf\n",d);
    }
}